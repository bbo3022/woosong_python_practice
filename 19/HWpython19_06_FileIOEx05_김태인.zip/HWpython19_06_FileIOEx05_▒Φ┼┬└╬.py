f=open('파일생성하기연습.txt','r')
data=f.read()
print(data)
f.close()
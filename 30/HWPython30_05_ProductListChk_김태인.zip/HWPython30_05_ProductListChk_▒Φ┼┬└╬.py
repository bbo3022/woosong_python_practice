import csv

file=open("product.csv","r", encoding="utf8")
lines=file.readlines()
# print(lines)
for i in lines:
  print(i)
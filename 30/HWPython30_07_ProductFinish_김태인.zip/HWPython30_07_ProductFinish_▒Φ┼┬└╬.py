import csv
import re

productFile=open("product.csv","r", encoding="utf8")
productList=productFile.readlines()

productList.pop(0)

def productChk(vItem):
	patt=re.compile('Mirror|Chair|Table|Sofa')
	vresult=""
	vItem=patt.search(vItem)
	if vItem:
		if vItem.group()=='Mirror':
			vresult='거울'
		elif vItem.group()=='Chair':
			vresult='의자'
		elif vItem.group()=='Table':
			vresult='테이블'
		elif vItem.group()=='Sofa':
			vresult='소파'


	return vresult

result=list(map(productChk, productList))
print(result)


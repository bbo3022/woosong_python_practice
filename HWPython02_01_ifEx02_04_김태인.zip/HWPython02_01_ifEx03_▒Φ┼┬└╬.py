a = 33
b = 33
if b > a:
  print("b is greater than a")
elif b == a:
	print("a and b are equal")
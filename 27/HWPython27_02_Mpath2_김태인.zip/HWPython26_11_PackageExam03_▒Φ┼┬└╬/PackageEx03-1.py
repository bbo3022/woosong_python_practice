import game.sound.echo.echo_test
#import는 모듈이나 페키지. 근데 이건 함수가 와서 오류.